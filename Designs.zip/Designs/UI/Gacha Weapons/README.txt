PROJECT STARFALL - GACHA WEAPON ICONS

19 separate transparent PNG icons:
- 3-star: 10 icons (weapon/role options)
- 4-star: 5 icons (rare weapons)
- 5-star: 4 icons (legendary/signature-style weapons)

These are visual placeholder concepts. Assign actual weapon names, drop rates, character associations, and gameplay stats in your Java data/configuration. For signature weapons, use one per playable character and explicitly map each weapon to its owner. Icons are cropped from a generated sprite sheet; inspect at your target display size before shipping.
