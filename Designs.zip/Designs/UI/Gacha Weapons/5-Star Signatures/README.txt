PROJECT STARFALL — FIVE SIGNATURE WEAPON CONCEPTS

Rin — Starfall Blade: increases ATK and skill damage.
Caster — Astral Core: increases magic attack and reduces skill cooldown.
Gilgamesh — Ragnarok Bow: increases ATK, critical rate, and range.
Lancer — Verdant Lance: increases HP and movement speed.
Shionne — Celestial Hymn: increases HP and healing power.

These are visual concept icons and suggested effects; tune values during balancing. Each PNG is a separate 128x128 image.
