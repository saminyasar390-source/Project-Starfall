PROJECT STARFALL — UI ICONS

All PNGs in this folder are separate 64x64 images, grouped into folders.

Player-character folders: Rin_Sword_Class, Caster_Arcane_Mage, Gilgamesh_Archer, Lancer_Spear_Class, Shionne_Ranger. Each includes skill, upgrade, weapon, passive, special ability, and alternate weapon icons.
Currency/ contains gold icons intended for the gacha banner. Consumables/ contains potion, scroll, food, bomb, and utility item icons. XP_Gems/ contains five gem variants. General_Skills/ and General_Upgrades/ provide reusable extras.

Note: These are newly generated generic fantasy UI icons inspired by the classes/roles in your project, not literal depictions of copyrighted character signature abilities. They retain the dark tile/frame backgrounds from the generated sprite sheet for legibility. If you prefer transparent icon-only art, the tiles can be processed separately.
